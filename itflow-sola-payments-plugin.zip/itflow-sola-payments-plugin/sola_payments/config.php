<?php
return [
    'xKey' => '',
    'ifields' => '',
    'enabled' => false,
    'customer_visible' => false,
    'sandbox' => true,
];